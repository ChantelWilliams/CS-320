
import java.util.ArrayList;

public class ContactService 
{
	ArrayList<Contact> contacts;

	public ContactService() 
	{
		contacts = new ArrayList<>();
	}

	// Add and update contacts
	public boolean addContacts(Contact contactNew) 
	{
		boolean existingContacts = false;
		for (Contact i : contacts) 
		{
			if (i.grabContactID().equalsIgnoreCase(contactNew.grabContactID())) 
			{
				existingContacts = true;
				break;
			}
		}

		if (!existingContacts)
		{
			contacts.add(contactNew);
			return true;
		} 
		else 
		{
			return false;
		}
	}

	// delete contacts
	public boolean deleteContacts(String contactID)
	{
		boolean deleted = false;
		for (Contact i : contacts) 
		{
			if (i.grabContactID().equalsIgnoreCase(contactID)) 
			{
				contacts.remove(i);
				deleted = true;
				break;
			}
		}
		return deleted;
	}

	// first name update 
	public boolean firstNameUpdate(String contactID, String firstNameNew) 
	{
		boolean updated = false;
		for (Contact i : contacts) 
		{
			if (i.grabContactID().equalsIgnoreCase(contactID)) 
			{
				i.setfName(firstNameNew);
				updated = true;
				break;
			}
		}
		return updated;
	}

	// last name update
	public boolean lastNameUpdate(String contactID, String lastNameNew) 
	{
		boolean updated = false;
		for (Contact i : contacts) 
		{
			if (i.grabContactID().equalsIgnoreCase(contactID)) 
			{
				i.setlName(lastNameNew);
				updated = true;
				break;
			}
		}
		return updated;
	}

	// contact number update 
	public boolean contactNumberUpdate(String contactID, String newNumber) 
	{
		boolean updated = false;
		for (Contact i : contacts) 
		{
			if (i.grabContactID().equalsIgnoreCase(contactID)) 
			{
				i.setPhoneNumber(newNumber);
				updated = true;
				break;
			}
		}
		return updated;
	}

	// address update
	public boolean addressUpdate(String contactID, String newAddress) 
	{
		boolean updated = false;
		for (Contact i : contacts)
		{
			if (i.grabContactID().equalsIgnoreCase(contactID))
			{
				i.setAddress(newAddress);
				updated = true;
				break;
			}
		}
		return updated;
	}
	

	public void showAllContacts()
	{
		for(Contact i: contacts)
		{
			System.out.println(i.toString());
		}
	}
	

}