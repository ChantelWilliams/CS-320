public class Contact 
{
	public static void main(String[] args) 
	{

	}
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
		
	//  required unique contact ID string
	public Contact(String contactId,String firstName,String nameLast,String phone,String address)
	{
		if(contactId.length() <= 10 && contactId != null) 
		{
			this.contactID = contactId;
		}
			this.setfName(firstName);
			this.setlName(nameLast);
			this.setPhoneNumber(phone);
			this.setAddress(address);
	}

// required firstName String field that cannot be longer than 10 characters
public void setfName(String firstName) 
{
	if(firstName.length() <= 10 && firstName != null) 
	{
		this.firstName = firstName;
	}
}

// required lastName String field that cannot be longer than 10 characters. 
public void setlName(String nameLast) 
{
	if(nameLast.length() <= 10 && nameLast != null) 
	{
		this.lastName = nameLast;
	}
}

// required phone String field that must be exactly 10 digits.
public void setPhoneNumber(String phoneNumber) 
{
	if(phoneNumber.length() == 10 && phoneNumber != null) 
	{
		this.phoneNumber = phoneNumber;
	}
}

//required address field that must be no longer than 30 characters
public void setAddress(String address) 
{
	if(address.length() <= 30 && address != null) 
	{
		this.address = address;
	}
}

//returns the following 
public String grabContactID() 
{
	return contactID;
}

public String grabFirstName() 
{
	return firstName;
}

public String grabLastName() 
{
	return lastName;
}

public String grabPhoneNumber() 
{
	return phoneNumber;
}

public String grabAddress()
{
	return address;
}


}

	
	

